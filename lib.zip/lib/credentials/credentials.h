#ifndef __CREDENTIALS_H__
#define __CREDENTIALS_H__


// Wifi parameters
const char * ssid = "2-GZDYQ6ST0PSJLZM0"; // your network SSID (name)
const char * pass = "59706458";           // your network password

const char* host = "10.14.0.20"; //raspberry
const int   port = 8080; //domoticz

//mqtt
IPAddress mqttServer_ip(10, 14, 0, 20);
uint16_t mqttServer_port = 1883;
const char* mqttServer_name = "mqtt";
const char* mqttServer_pass = "alegzx56pl";

#endif