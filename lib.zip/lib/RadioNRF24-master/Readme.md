#Radio NRF24 - receive and send data via NRF24L01+

This libarary is extracte from our Nettigo TinyBrd Core for [tinyBrd](https://nettigo.eu/products/wireless-sensor-tinybrd-arduino-ide-compatible) and supports [NRF24L01+](https://nettigo.eu/products/nrf24l01-module-wireless-communication-for-arduino) radio on Arduino UNO (and others boards too) with identical API like Radio libarry on tinyBrd. Name changed for Arduino to avoid clash with other _Radio_ library.

v 1.0.2
- Transactional SPI support;